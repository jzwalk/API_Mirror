<?php
/**
 * <strong style="color:red;">「班班碎碎念」站点必备插件</strong> <a href="https://github.com/lei2rock&/Typecho-Assets/tree/master/plugins/BanbanStyle" target="_blank">Github</a>
 * 
 * @package BanbanStyle
 * @author lei2rock&
 * @version 0.3.1
 * @link https://github.com/lei2rock&
 */
class BanbanStyle_Plugin implements Typecho_Plugin_Interface {
     /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'header');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'footer');
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}

    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){


        // CDN 加速域名
        $cdn = new Typecho_Widget_Helper_Form_Element_Text(
            'cdn',
            NULL,
            "https://",
            _t('CDN 加速域名：'),
            _t('【必填】你可以将本插件设置中涉及的文件放到 CDN 存储，然后在这里填写加速域名，需要加上 <code>https://</code>。')
        );
        $form->addInput($cdn->addRule('required', _t('CDN 加速域名不能为空，也可填写网站域名或者根目录 <code>/</code>。')));
        
        // Assets 目录
        $assets = new Typecho_Widget_Helper_Form_Element_Text(
            'assets',
            NULL,
            "/assets-my/",
            _t('Assets 目录：'),
            _t('【必填】填写 CDN 中的 Assets 文件夹路径。<br>
            （1）如果上面不是填写 <code>/</code> 而是域名，则开头结尾<strong>都需要</strong>加上 <code>/</code>。<br>
            （2）默认其中包含了<code>/css/</code>、<code>/js/</code>、<code>/img/</code>三个子文件夹。<br>
            （3）请确保子文件夹 <code>/img/</code> 下有 <code>favicon-16x16.png</code>、<code>favicon-32x32.png</code>、<code>apple-touch-icon.png</code>、<code>safari-pinned-tab.svg</code> 四个图标文件')
        );
        $form->addInput($assets->addRule('required', _t('Assets 目录不能为空。')));

        // Safari 标签页固定图标颜色
        $safariPinnedTabColor = new Typecho_Widget_Helper_Form_Element_Text(
            'safariPinnedTabColor',
            NULL,
            "#6c599f",
            _t('Safari 标签页固定图标颜色：'),
            NULL
        );
        $form->addInput($safariPinnedTabColor);

        // Google 搜索验证
        $googleVerify = new Typecho_Widget_Helper_Form_Element_Text(
            'googleVerify',
            NULL,
            "",
            _t('Google Search Console 验证码：'),
            NULL
        );
        $form->addInput($googleVerify);

        // 百度搜索资源平台验证
        $baiduVerify = new Typecho_Widget_Helper_Form_Element_Text(
            'baiduVerify',
            NULL,
            "",
            _t('百度搜索资源平台验证码：'),
            NULL
        );
        $form->addInput($baiduVerify);

        // Google 分析
        $googleAnalytics = new Typecho_Widget_Helper_Form_Element_Text(
            'googleAnalytics',
            NULL,
            "",
            _t('Google Analytics 识别码：'),
            NULL
        );
        $form->addInput($googleAnalytics);

    }

    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function render() {
        
    }

    /**
     *为header添加文件
     *@return void
     */
    public static function header() {
        $cdn = Typecho_Widget::widget('Widget_Options')->plugin('BanbanStyle')->cdn;
        $assets = Typecho_Widget::widget('Widget_Options')->plugin('BanbanStyle')->assets;
        $safariPinnedTabColor = Typecho_Widget::widget('Widget_Options')->plugin('BanbanStyle')->safariPinnedTabColor;
        $googleVerify = Typecho_Widget::widget('Widget_Options')->plugin('BanbanStyle')->googleVerify;
        $baiduVerify = Typecho_Widget::widget('Widget_Options')->plugin('BanbanStyle')->baiduVerify;
        $googleAnalytics = Typecho_Widget::widget('Widget_Options')->plugin('BanbanStyle')->googleAnalytics;

        echo '<meta http-equiv="Cache-Control" content="no-transform">';
        echo '<meta http-equiv="Cache-Control" content="no-siteapp">';
        echo '<meta name="google-site-verification" content="' . $googleVerify . '">';
        echo '<meta name="baidu-site-verification" content="' . $baiduVerify . '">';
        echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . $googleAnalytics . '"></script>';  
        echo '
<script data-pjax>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(\'js\', new Date());
  gtag(\'config\', \'' . $googleAnalytics . '\');
</script>';
        echo '<link rel="icon" type="image/png" sizes="16x16" href="' . $cdn . $assets . 'img/favicon-16x16.png">';
        echo '<link rel="icon" type="image/png" sizes="32x32" href="' . $cdn . $assets . 'img/favicon-32x32.png">';
        echo '<link rel="apple-touch-icon" sizes="180x180" href="' . $cdn . $assets . 'img/apple-touch-icon.png">';
        echo '<link rel="mask-icon" href="' . $cdn . $assets . 'img/safari-pinned-tab.svg" color="' . $safariPinnedTabColor . '">';
        echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5/css/all.min.css">';
        echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lei2rock&/Typecho-Plugin-macOScode@latest/static/macOScode.css" media="print" onload="this.media=\'all\'">';
        echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=EB+Garamond:400,400italic,700,700italic|Noto+Serif+SC:400,400italic,700,700italic&display=swap&subset=latin,latin-ext" media="print" onload="this.media=\'all\'">';

    }

    /**
     *为footer添加文件
     *@return void
     */
    public static function footer() {

        echo '<script src="https://cdn.jsdelivr.net/npm/pangu@4/dist/browser/pangu.min.js"></script>';
        echo '<script src="/usr/plugins/BanbanStyle/static/prism.js"></script>';

    }
}
