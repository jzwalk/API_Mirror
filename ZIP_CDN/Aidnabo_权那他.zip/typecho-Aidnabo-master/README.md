# typecho-aidnabo

警告
====
`Aidnabo` 插件的**文件夹名**必须为`Aidnabo`
`第一个A是大写`
`第一个A是大写`
`第一个A是大写`

介绍
==
**南博v2.2**开始，支持了对typecho博客的XmlRpc文件的快速更新以及接口安全、后台登陆两步验证。**从Github拉取**

`typecho插件` - `Aidnabo` 南博助手 - 配套插件 - XmlRpc更新、接口安全

>该插件适合`南博v2.2及其以后的版本`，其插件可以`快速更新XmlRpc文件`、`XmlRpc接口的安全`以及`后台登录的两步验证码`(默认关闭，若需使用则可开启)

声明
====

XmlRpc更新功能，下载使用 `Typecho_Http_Client` ，解压使用 `ZipArchive`

准备
====

 - 下载软件 **南博v2.2++**
 - 下载插件 **南博助手** 插件[点击下载][3]

安装
====

 - 安装南博
 - 安装插件

* 该插件适合`南博v2.2及其以后的版本`，其插件可以`快速更新XmlRpc文件`、`XmlRpc接口的安全`以及`后台登录的两步验证码`(默认关闭，若需使用则可开启)
* 南博助手 [点击前往下载插件](https://github.com/kraity/typecho-aidnabo/releases) ，然后点击`Source code`进行下载，上传插件，插件名一定要为`Aidnabo`，第一个A是`大写`。若需详细教程 - [点击查看详细教程](https://krait.cn/major/2038.html)
* 然后你就可以`跳过`了`步骤1`和`步骤2`
