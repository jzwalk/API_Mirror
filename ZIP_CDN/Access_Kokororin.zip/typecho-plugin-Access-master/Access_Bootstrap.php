<?php
define('__ACCESS_PLUGIN_ROOT__', __DIR__);

require_once __ACCESS_PLUGIN_ROOT__ . '/Access_Autoloader.php';
Access_Autoloader::register();
