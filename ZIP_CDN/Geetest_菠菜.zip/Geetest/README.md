### Geetest for Typecho 

#### 使用方法

下载插件后，启用即可自动添加极验验证到后台登录页面
