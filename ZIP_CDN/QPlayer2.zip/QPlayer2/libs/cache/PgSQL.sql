CREATE TABLE "%table%" (
    "key" CHAR(32) NOT NULL,
    "data" TEXT NOT NULL,
    "time" INT NOT NULL,
    PRIMARY KEY ("key")
);