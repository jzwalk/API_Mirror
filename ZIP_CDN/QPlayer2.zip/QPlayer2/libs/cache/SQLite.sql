CREATE TABLE `%table%` (
    `key` VARCHAR(32) NOT NULL PRIMARY KEY,
    `data` TEXT,
    `time` INT(10) DEFAULT NULL
);